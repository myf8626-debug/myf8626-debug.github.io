# draft-thesis-docx

Codex skill for drafting and revising Chinese vocational-college and undergraduate thesis `.docx` files while preserving school templates.

The skill focuses on formatting integrity and review gates:

- Protect cover pages and pre-abstract front matter with complete DOCX part hashing.
- Preserve template-defined headers, footers, pagination, section breaks, and styles.
- Require outline approval before drafting body chapters.
- Use uppercase Roman numerals for abstract-to-body front matter and restart Arabic numbering at Chapter 1 unless the template specifies otherwise.
- Audit standard three-line tables, figures, captions, citations, references, and unsupported test-result claims.
- Render DOCX files to page PNGs on Windows with automatic LibreOffice and Poppler discovery.

## Install

Clone the repository:

```powershell
git clone https://github.com/myf8626-debug/draft-thesis-docx.git
```

Copy the skill folder into your Codex skills directory:

```powershell
Copy-Item -Recurse -Force .\draft-thesis-docx\draft-thesis-docx "$HOME\.codex\skills\draft-thesis-docx"
```

Restart or refresh Codex so the skill appears in the available skills list. Invoke it with:

```text
$draft-thesis-docx
```

## Requirements

- Python 3.10 or later.
- Microsoft Word is recommended when immediate TOC and page-field refresh is required.
- LibreOffice and Poppler are used for Windows render QA. The bundled renderer also checks common Codex desktop tool locations.
- For DOCX editing and page-image inspection, use the Codex Documents skill when available.

## Academic Integrity

This skill is designed for legitimate drafting, formatting, revision, and QA workflows. It must not fabricate references, test logs, research data, charts, screenshots, questionnaire results, or conclusions. Unsupported test-result claims are blocked unless traceable user-provided records exist or the text is explicitly marked as awaiting real verification.

## Reproducible protection checks

The implementation was designed from school thesis-writing requirements. **It has not been validated on a real thesis.** Current tests use minimal synthetic ZIP/XML fixtures, not complete renderable school templates.

Run the regression suite from the repository root:

```powershell
python tests/evaluate.py
```

The current 14 tests cover unchanged files, permitted body edits, cover mutations, header/image/style/theme dependencies, relationship changes, missing boundaries, incomplete/legacy snapshots, CLI failure reporting, input/output path aliases (including hard links), and report replacement failures. Dependency mutations include multiple subcases. The report includes input hashes and limitations in `reports/frontmatter-regression.json`; this is not a visual rendering or citation-truth score.

Create a snapshot from a trusted original, then audit an edited copy:

```powershell
python draft-thesis-docx/scripts/verify_frontmatter_unchanged.py trusted-template.docx --write-snapshot frontmatter.json
python draft-thesis-docx/scripts/audit_frontmatter.py edited.docx --snapshot frontmatter.json --report audit.json
```

Use `--boundary-text` on the snapshot command if the default abstract heading is not the intended boundary. The boundary heading and following body are excluded from protected front matter. Global rendering parts are checked conservatively: even a legitimate style edit can be blocked and needs review, not automatic acceptance. Preserve the original snapshot rather than regenerating it from a changed document.

`audit_frontmatter.py` returns exit code 0 for `passed`, 1 for `blocked` or `error`, and 2 for an output path aliasing an input, and writes JSON identifying changed parts. It refuses legacy or incomplete snapshots instead of silently claiming full protection. Byte equality cannot establish correct pagination or truthful references; Word/LibreOffice page inspection remains a separate step.

## License

MIT

### Output preservation

The audit command rejects report paths that resolve to the document or snapshot, including existing hard links. The snapshot command also refuses to write JSON over its input DOCX. Reports are written to a sibling temporary file and replaced only after writing completes; a failed replacement preserves the previous report. This prevents accidental path mistakes, not hostile concurrent filesystem changes.
