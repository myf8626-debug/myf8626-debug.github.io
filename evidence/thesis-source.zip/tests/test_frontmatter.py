import json
import sys
import tempfile
import unittest
import zipfile
import subprocess
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'draft-thesis-docx/scripts'))
from verify_frontmatter_unchanged import protected_digest
from audit_frontmatter import audit, main as audit_main

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
BASE = {
 'word/document.xml': f'<w:document xmlns:w="{W}" xmlns:r="{R}"><w:body><w:p><w:r><w:t>合成封面</w:t></w:r><w:headerReference r:id="rH"/></w:p><w:p><w:r><w:t>摘要</w:t></w:r></w:p><w:p><w:r><w:t>正文</w:t></w:r></w:p></w:body></w:document>',
 'word/_rels/document.xml.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rH" Target="header1.xml" Type="header"/></Relationships>',
 'word/header1.xml': f'<w:hdr xmlns:w="{W}" xmlns:r="{R}"><w:p><w:r><w:t>合成页眉</w:t></w:r><w:drawing r:embed="rI"/></w:p></w:hdr>',
 'word/_rels/header1.xml.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rI" Target="media/logo.png" Type="image"/></Relationships>',
 'word/media/logo.png': 'synthetic-image-bytes',
 'word/styles.xml': f'<w:styles xmlns:w="{W}"/>',
 'word/settings.xml': f'<w:settings xmlns:w="{W}"/>',
 'word/numbering.xml': f'<w:numbering xmlns:w="{W}"/>',
 'word/theme/theme1.xml': '<theme>synthetic</theme>'
}

class ProtectionTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name); self.doc=self.root/'fixture.docx'; self.snapshot=self.root/'snapshot.json'
  self.write(BASE)
  self.snapshot.write_text(json.dumps(protected_digest(self.doc,None)),encoding='utf-8')
 def write(self,parts):
  with zipfile.ZipFile(self.doc,'w') as z:
   for name,value in parts.items(): z.writestr(name,value)
 def test_unchanged(self): self.assertEqual(audit(self.doc,self.snapshot)['status'],'passed')
 def test_allowed_body_edit(self):
  self.write({**BASE,'word/document.xml':BASE['word/document.xml'].replace('正文','已修改的正文')})
  self.assertEqual(audit(self.doc,self.snapshot)['status'],'passed')
 def test_cover_edit(self):
  self.write({**BASE,'word/document.xml':BASE['word/document.xml'].replace('合成封面','误改封面')})
  self.assertEqual(audit(self.doc,self.snapshot)['status'],'blocked')
 def test_dependency_mutations(self):
  for name in ['word/header1.xml','word/media/logo.png','word/styles.xml','word/settings.xml','word/numbering.xml','word/theme/theme1.xml']:
   with self.subTest(part=name):
    self.write({**BASE,name:BASE[name]+' '})
    r=audit(self.doc,self.snapshot);self.assertEqual(r['status'],'blocked')
    self.assertTrue(any(name in x.get('parts',[]) for x in r['changes']))
 def test_relationship_target_change(self):
  self.write({**BASE,'word/_rels/document.xml.rels':BASE['word/_rels/document.xml.rels'].replace('header1.xml','header2.xml')})
  self.assertEqual(audit(self.doc,self.snapshot)['status'],'blocked')
 def test_missing_boundary(self):
  self.write({**BASE,'word/document.xml':BASE['word/document.xml'].replace('摘要','正文开始')})
  with self.assertRaises(ValueError): audit(self.doc,self.snapshot)
 def test_legacy_snapshot_not_full_protection(self):
  self.snapshot.write_text('{"schema_version":1}',encoding='utf-8')
  with self.assertRaises(ValueError): audit(self.doc,self.snapshot)
 def test_incomplete_snapshot_rejected(self):
  self.snapshot.write_text('{"schema_version":2}',encoding='utf-8')
  with self.assertRaises(ValueError): audit(self.doc,self.snapshot)
 def test_cli_writes_failure_report(self):
  self.write({**BASE,'word/document.xml':BASE['word/document.xml'].replace('合成封面','误改封面')})
  report=self.root/'report.json'
  result=subprocess.run([sys.executable,str(ROOT/'draft-thesis-docx/scripts/audit_frontmatter.py'),str(self.doc),'--snapshot',str(self.snapshot),'--report',str(report)],capture_output=True)
  self.assertEqual(result.returncode,1)
  self.assertEqual(json.loads(report.read_text(encoding='utf-8'))['status'],'blocked')
 def test_missing_boundary_field_rejected(self):
  value=json.loads(self.snapshot.read_text(encoding='utf-8'));del value['boundary_text']
  self.snapshot.write_text(json.dumps(value),encoding='utf-8')
  with self.assertRaises(ValueError): audit(self.doc,self.snapshot)
 def test_report_cannot_replace_inputs(self):
  for target in [self.doc,self.snapshot]:
   with self.subTest(target=target.name):
    before=target.read_bytes()
    with patch.object(sys,'argv',['audit',str(self.doc),'--snapshot',str(self.snapshot),'--report',str(target)]):
     self.assertEqual(audit_main(),2)
    self.assertEqual(target.read_bytes(),before)
 def test_report_hardlink_cannot_replace_input(self):
  alias=self.root/'alias.json'
  try: alias.hardlink_to(self.snapshot)
  except OSError: self.skipTest('Filesystem does not support hard links')
  before=self.snapshot.read_bytes()
  with patch.object(sys,'argv',['audit',str(self.doc),'--snapshot',str(self.snapshot),'--report',str(alias)]):
   self.assertEqual(audit_main(),2)
  self.assertEqual(self.snapshot.read_bytes(),before)
 def test_report_replace_failure_keeps_previous_report(self):
  report=self.root/'report.json';report.write_text('{"previous":true}',encoding='utf-8')
  with patch.object(sys,'argv',['audit',str(self.doc),'--snapshot',str(self.snapshot),'--report',str(report)]), patch('audit_frontmatter.os.replace',side_effect=OSError('simulated disk failure')):
   with self.assertRaises(OSError): audit_main()
  self.assertEqual(report.read_text(encoding='utf-8'),'{"previous":true}')
  self.assertEqual(list(self.root.glob('.audit-*.tmp')),[])
 def test_snapshot_cannot_replace_document(self):
  before=self.doc.read_bytes()
  result=subprocess.run([sys.executable,str(ROOT/'draft-thesis-docx/scripts/verify_frontmatter_unchanged.py'),str(self.doc),'--write-snapshot',str(self.doc)],capture_output=True)
  self.assertNotEqual(result.returncode,0)
  self.assertEqual(self.doc.read_bytes(),before)

if __name__ == '__main__': unittest.main()
