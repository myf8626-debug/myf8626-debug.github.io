"""Export synthetic package-mutation evidence. This is not real-thesis validation."""
import hashlib
import json
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'kind':'synthetic_docx_package_regression','generated_at':datetime.now(timezone.utc).isoformat(),
 'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
 'passed':result.wasSuccessful(),'real_thesis_validated':False,
 'sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
           for p in [ROOT/'tests/test_frontmatter.py',ROOT/'draft-thesis-docx/scripts/audit_frontmatter.py',ROOT/'draft-thesis-docx/scripts/verify_frontmatter_unchanged.py']},
 'limitations':['Fixtures are minimal synthetic ZIP/XML packages, not renderable school templates.',
 'No real thesis or Word/LibreOffice rendering validation in this run.',
 'Hash equality does not establish visual correctness or factual/citation truth.']}
out=ROOT/'reports';out.mkdir(exist_ok=True)
(out/'frontmatter-regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if result.wasSuccessful() else 1)
