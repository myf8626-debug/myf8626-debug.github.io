---
name: draft-thesis-docx
description: Draft and revise Chinese vocational-college and undergraduate theses in `.docx` format while preserving the supplied school template or the existing document formatting. Use when Codex needs to inspect a thesis template, gather writing requirements, propose an outline for approval, write abstracts and thesis chapters, edit an existing thesis, add HTML-authored figures or tables, collect verifiable academic references, update a Word table of contents, configure section-based Roman and Arabic page numbering, or perform formatting QA against a school template.
---

# Thesis DOCX Assistant

## Overview

Draft or revise a thesis inside a copy of the user's `.docx` file. Treat the school template as the formatting authority, preserve protected front matter, require outline approval before drafting body chapters, use verifiable evidence, and visually inspect the final document page by page.

## Non-negotiable rules

- Work on a copy of the input `.docx`. Never overwrite the user's original file.
- Preserve the cover, declarations, authorization pages, and other protected front matter exactly unless the user explicitly requests a specific edit.
- Protect front matter structurally, not only visually. Snapshot the body XML before the abstract, recursively referenced internal parts such as images and header/footer dependencies, and global rendering parts such as styles, numbering, settings, fonts, and themes. Treat any protected hash difference as a blocking defect until reviewed.
- Draft the Chinese abstract and any required English abstract while preserving their template styles.
- Use styles, numbering definitions, captions, cross-references, page settings, headers, footers, and table geometry already present in the template. Do not approximate formatting by eye.
- Treat the template and the school's written specification as authoritative for every header and footer. Preserve section-specific content, first-page differences, odd/even-page differences, fields, and linkage to previous sections. Do not replace template headers or footers with generic content.
- When a title changes, update only main-body and later-section headers. Use section-aware header synchronization so cover, declaration, abstract, and TOC headers remain untouched.
- Use real Word section breaks and page-number fields. Do not type page numbers as plain text.
- Unless the template or school specification explicitly requires another scheme, keep pages before the Chinese abstract template-controlled, start uppercase Roman numbering (`I`, `II`, `III`) at the Chinese abstract, continue uppercase Roman numbering through the final page before Chapter 1, and restart with Arabic numeral `1` on the first page of Chapter 1. Continue Arabic numbering through references, acknowledgements, and appendices unless the template explicitly resets it.
- When no school template is supplied, preserve the existing thesis document's formatting and make minimal local edits.
- Present an outline and wait for explicit user approval before drafting body chapters. You may inspect files, gather requirements, search references, and refine the outline before approval.
- Never fabricate references, quotations, research data, experiments, questionnaire results, cases, screenshots, or conclusions.
- Use the school's existing citation and bibliography format. Do not silently convert it to another standard.
- Author explanatory figures as editable HTML/CSS/SVG source before rendering an image for Word. Use real supplied data for charts. Do not generate fake empirical visuals.
- For any `.docx` creation or edit, use the installed `documents` skill render-and-inspect workflow. Do not deliver a document before page-image QA unless rendering is unavailable.

## Workflow

### 1. Collect requirements

Read [references/intake-checklist.md](references/intake-checklist.md). Ask only for missing information that affects structure, evidence, or formatting. Request the school template, example thesis, writing specification, thesis title, discipline, target length, deadline, and available source materials.

Clarify which parts must be written: Chinese abstract, English abstract, body chapters, references, appendices, and acknowledgements. Do not assume that user-provided examples are factual sources.

### 2. Inspect and protect the template

Create a working copy. Run:

```powershell
python scripts/inspect_template.py input.docx --out-json template-report.json
python scripts/inspect_sections.py input.docx --out-json section-report.json
python scripts/verify_frontmatter_unchanged.py input.docx --boundary-text "摘要" --write-snapshot protected-frontmatter.json
python scripts/audit_thesis_consistency.py input.docx --boundary-text "摘要" --canonical-title "论文题目" --out-json baseline-consistency-report.json --fail-on never
```

The protected-front-matter script normalizes heading spacing, so `摘要` matches headings such as `摘  要`, including full-width and invisible spacing variants. It also accepts common Chinese abstract aliases such as `中文摘要`. Omit `--boundary-text` to auto-detect a common Chinese abstract heading. Keep explicit `--boundary-text "摘要"` in normal thesis work so the intended editable boundary remains visible in the command log. New snapshots include complete front-matter dependency and rendering-part hashes. Recreate legacy snapshots before editing when they report body-XML-only protection.

Review the reports and inspect the rendered template pages. Determine the exact protected boundary from the script's reported matched heading. Record the styles used for each thesis component before editing. Identify the Chinese abstract page and the first Chapter 1 page. Record section-break locations, page-number formats and restart values, header/footer references, first-page behavior, odd/even-page behavior, and linkage between sections. Review baseline consistency findings so existing defects are not silently attributed to the edit.

### 3. Propose the outline

Build an outline that fits the discipline, target length, and template hierarchy. Include the intended argument, evidence needs, figure plan, table plan, and likely reference search terms. Ask the user for explicit approval.

Do not draft body chapters until approval is received. After approval, treat material outline changes as a new approval gate.

### 4. Build the evidence inventory

Read [references/citation-policy.md](references/citation-policy.md). Search professional academic sources when access is available. Use public metadata and abstracts only within their limits; request legally obtained PDFs from the user when full-text support is required. Do not bypass authentication, subscriptions, or download controls.

Maintain a CSV inventory and validate its structure:

```powershell
python scripts/validate_references.py references.csv
```

Prefer references published within the latest five calendar years. Allow older standards, policies, and foundational works only when justified. Verify bibliographic metadata before including a source in the final bibliography. When a draft DOCX exists, run the enhanced cross-check:

```powershell
python scripts/validate_references.py references.csv --docx edited.docx --out-json reference-audit.json
```

Use `--check-links` when network verification is appropriate. Treat DOI syntax and citation-number mismatches as blocking. HTTP reachability checks do not replace manual CNKI, VIP, DOI, academic-database, or full-text verification.

### 5. Draft inside the template

Write the abstract, keywords, approved body chapters, references, appendices, and acknowledgements according to the confirmed scope. Keep claims proportional to the available evidence. Distinguish literature-backed statements from user-provided facts and from analysis or inference.

For figures, copy [assets/html-figure-template.html](assets/html-figure-template.html) into the work directory and edit the copy. Retain the edited HTML source with the deliverables. Insert the rendered figure using the template's caption style and numbering rules. Create data charts only from traceable data and retain the source dataset.

For tables, use real Word tables and match the template's fonts, paragraph settings, widths, alignment, and caption style. Follow an explicit template or school table-border specification when one exists. Otherwise, default to a standard three-line table: no vertical borders, a `1.5 pt` top border, a `0.75 pt` separator below the final header row, and a `1.5 pt` bottom border. Do not add internal horizontal borders beyond the header separator unless the template requires them. For the table of contents, use Word heading styles and update the existing TOC field instead of typing entries manually.

Keep page numbers field-driven. Apply uppercase Roman numbering from the Chinese abstract through the page before Chapter 1 and restart Arabic numbering at `1` on the first Chapter 1 page. If a needed pagination boundary does not align with an existing section break, insert the smallest necessary section break and clone the applicable template header/footer configuration. If automatic TOC refresh is unavailable and a static TOC fallback is unavoidable, recalculate page numbers after final pagination and disclose that the TOC is static.

When the thesis title changes, create a new copy and synchronize only main-body and later-section headers:

```powershell
python scripts/sync_body_headers.py edited.docx --out headers-synced.docx --new-title "新论文题目" --old-title "旧论文题目" --body-start-text "1 绪论" --out-json header-sync-report.json
```

Never use a global search-and-replace across all header parts. Re-run the protected-front-matter verifier after header synchronization.

### 6. Verify integrity and formatting

Run the protected-region check against the edited file:

```powershell
python scripts/verify_frontmatter_unchanged.py edited.docx --snapshot protected-frontmatter.json
python scripts/inspect_sections.py edited.docx --out-json final-section-report.json
python scripts/audit_thesis_consistency.py edited.docx --boundary-text "摘要" --canonical-title "论文题目" --legacy-term "需要移除的旧题目" --test-record tests.xlsx --out-json final-consistency-report.json
python scripts/audit_three_line_tables.py edited.docx --out-json three-line-table-audit.json --fail-on-deviation
python scripts/audit_thesis_images.py edited.docx --boundary-text "摘要" --out-json image-audit.json
python scripts/validate_references.py references.csv --docx edited.docx --out-json reference-audit.json
```

Pass each known stale title or system name as a separate `--legacy-term`. Pass each user-provided test log, test-case sheet, screenshot bundle, or verification record as a separate `--test-record`. Treat audit errors as blocking. If no test record exists, replace unsupported claims such as `测试结果表明` or `运行稳定` with an explicit unverified statement such as `待实际测试验证`.

Treat three-line-table deviations as blocking unless the school template explicitly requires another border style. Review image-audit errors before delivery: each image must have an adjacent caption, figure numbering must be continuous, body references must resolve, and chart-like figures must include a nearby data source or `待核验` marker.

Before final rendering, refresh TOC and pagination fields into a new copy on Windows:

```powershell
python scripts/refresh_docx_fields_windows.py edited.docx --out refreshed.docx --mode word
```

If Microsoft Word automation is unavailable, use `--mode mark-on-open`, disclose that cached field results were not recalculated immediately, and require a final Word-open refresh before submission.

Read [references/quality-gates.md](references/quality-gates.md). Render the `.docx` to page PNGs with the installed `documents` skill, inspect every page, fix defects, and repeat until clean. On Windows, when the installed renderer cannot locate LibreOffice or Poppler, run:

```powershell
python scripts/render_docx_windows.py edited.docx --output-dir final-render --emit-pdf
```

Confirm styles, indentation, line spacing, headings, TOC, captions, tables, references, English text, acknowledgements, template-defined headers and footers, and section-based page numbering. Confirm pages before the Chinese abstract follow the template, the abstract-to-Chapter-1 range uses uppercase Roman numerals, and the first Chapter 1 page restarts as Arabic `1`.

## Delivery

Deliver:

- The final `.docx`.
- The verified reference inventory.
- Editable HTML/CSS/SVG figure sources and traceable datasets used for charts.
- A short note identifying any unresolved limitation, missing source, or QA step that could not be completed.

Do not present unsupported content as complete. If evidence or required user data is missing, mark the affected section and request the missing material.
