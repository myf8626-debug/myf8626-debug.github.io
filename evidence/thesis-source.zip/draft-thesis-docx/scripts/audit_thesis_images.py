#!/usr/bin/env python3
"""Audit thesis image placement, clarity, numbering, references, and chart provenance."""

from __future__ import annotations

import argparse
import json
import posixpath
import re
import struct
import zipfile
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET

from verify_frontmatter_unchanged import W, element_text, find_boundary

R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PR = "{http://schemas.openxmlformats.org/package/2006/relationships}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
V = "{urn:schemas-microsoft-com:vml}"
WP = "{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}"
FIGURE_PATTERN = re.compile(r"^图\s*(\d+)\s*[-－—.]\s*(\d+)")
FIGURE_REFERENCE_PATTERN = re.compile(r"图\s*(\d+)\s*[-－—.]\s*(\d+)")
CHART_PATTERN = re.compile(r"(?:分析|统计|分布|占比|趋势|排行|状态|看板|图表|数据)")
SOURCE_PATTERN = re.compile(r"(?:数据来源|资料来源|来源[:：]|用户提供|待核验|待实际数据验证)")


def relationship_map(archive: zipfile.ZipFile) -> dict[str, str]:
    root = ET.fromstring(archive.read("word/_rels/document.xml.rels"))
    return {
        item.get("Id", ""): item.get("Target", "")
        for item in root.findall(f"{PR}Relationship")
    }


def image_size(payload: bytes) -> tuple[int | None, int | None]:
    if payload.startswith(b"\x89PNG\r\n\x1a\n") and len(payload) >= 24:
        return struct.unpack(">II", payload[16:24])
    if payload[:3] == b"\xff\xd8\xff":
        offset = 2
        while offset + 9 < len(payload):
            if payload[offset] != 0xFF:
                offset += 1
                continue
            marker = payload[offset + 1]
            offset += 2
            if marker in {0xD8, 0xD9}:
                continue
            if offset + 2 > len(payload):
                break
            length = struct.unpack(">H", payload[offset:offset + 2])[0]
            if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
                height, width = struct.unpack(">HH", payload[offset + 3:offset + 7])
                return width, height
            offset += length
    if payload.startswith((b"GIF87a", b"GIF89a")) and len(payload) >= 10:
        return struct.unpack("<HH", payload[6:10])
    return None, None


def embedded_relationship_ids(paragraph: ET.Element) -> list[str]:
    ids = [node.get(f"{R}embed") for node in paragraph.iter(f"{A}blip")]
    ids.extend(node.get(f"{R}id") for node in paragraph.iter(f"{V}imagedata"))
    return [relationship_id for relationship_id in ids if relationship_id]


def rendered_extent_inches(paragraph: ET.Element) -> tuple[float | None, float | None]:
    extent = next(iter(paragraph.iter(f"{WP}extent")), None)
    if extent is None:
        return None, None
    try:
        return int(extent.get("cx", "0")) / 914400, int(extent.get("cy", "0")) / 914400
    except ValueError:
        return None, None


def figure_id(match: re.Match[str]) -> str:
    return f"图{match.group(1)}-{match.group(2)}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    parser.add_argument("--boundary-text", default="摘要")
    parser.add_argument("--out-json", type=Path)
    parser.add_argument("--min-dpi", type=float, default=150)
    parser.add_argument("--fail-on", choices=("error", "warning", "never"), default="error")
    args = parser.parse_args()
    if not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")

    try:
        with zipfile.ZipFile(args.docx) as archive:
            document = ET.fromstring(archive.read("word/document.xml"))
            relationships = relationship_map(archive)
            body = document.find(f"{W}body")
            if body is None:
                raise ValueError("word/document.xml does not contain a body element")
            boundary_index, matched_boundary, _, _ = find_boundary(body, args.boundary_text)
            children = list(body)
            records = []
            captions = {}
            caption_locations = {}
            references = set()
            issues = []

            for child_index, child in enumerate(children[boundary_index:], start=boundary_index):
                if child.tag != f"{W}p":
                    continue
                text = element_text(child)
                caption_match = FIGURE_PATTERN.match(text.strip())
                if caption_match:
                    identifier = figure_id(caption_match)
                    captions[identifier] = text
                    caption_locations[identifier] = child_index
                elif text:
                    references.update(
                        figure_id(match) for match in FIGURE_REFERENCE_PATTERN.finditer(text)
                    )

            for child_index, child in enumerate(children[boundary_index:], start=boundary_index):
                if child.tag != f"{W}p":
                    continue
                relationship_ids = embedded_relationship_ids(child)
                if not relationship_ids:
                    continue
                next_nonempty = None
                for following_index in range(child_index + 1, min(len(children), child_index + 4)):
                    following = children[following_index]
                    if following.tag == f"{W}p" and element_text(following):
                        next_nonempty = (following_index, element_text(following))
                        break
                caption_match = FIGURE_PATTERN.match(next_nonempty[1].strip()) if next_nonempty else None
                caption_identifier = figure_id(caption_match) if caption_match else None
                width_inches, height_inches = rendered_extent_inches(child)
                for relationship_id in relationship_ids:
                    target = relationships.get(relationship_id)
                    part = posixpath.normpath(posixpath.join("word", target)) if target else None
                    width_pixels = height_pixels = None
                    if part and part in archive.namelist():
                        width_pixels, height_pixels = image_size(archive.read(part))
                    dpi_x = width_pixels / width_inches if width_pixels and width_inches else None
                    dpi_y = height_pixels / height_inches if height_pixels and height_inches else None
                    min_effective_dpi = min(value for value in (dpi_x, dpi_y) if value is not None) if dpi_x or dpi_y else None
                    nearby_text = " ".join(
                        element_text(children[index])
                        for index in range(max(boundary_index, child_index - 3), min(len(children), child_index + 5))
                        if children[index].tag == f"{W}p"
                    )
                    chart_like = bool(caption_identifier and CHART_PATTERN.search(captions.get(caption_identifier, "")))
                    source_marked = bool(SOURCE_PATTERN.search(nearby_text))
                    record = {
                        "body_child_index": child_index,
                        "relationship_id": relationship_id,
                        "part": part,
                        "caption_id": caption_identifier,
                        "caption_adjacent": bool(caption_identifier),
                        "pixel_width": width_pixels,
                        "pixel_height": height_pixels,
                        "rendered_width_inches": width_inches,
                        "rendered_height_inches": height_inches,
                        "minimum_effective_dpi": min_effective_dpi,
                        "chart_like": chart_like,
                        "source_or_unverified_mark_nearby": source_marked,
                    }
                    records.append(record)
                    if not caption_identifier:
                        issues.append({"severity": "error", "code": "image-without-adjacent-caption", "record": record})
                    if min_effective_dpi is not None and min_effective_dpi < args.min_dpi:
                        issues.append({"severity": "warning", "code": "low-image-resolution", "record": record})
                    if chart_like and not source_marked:
                        issues.append({"severity": "error", "code": "chart-source-or-unverified-mark-missing", "record": record})

            by_chapter = defaultdict(list)
            for identifier in captions:
                match = FIGURE_PATTERN.match(identifier)
                if match:
                    by_chapter[int(match.group(1))].append(int(match.group(2)))
            for chapter, values in sorted(by_chapter.items()):
                ordered = sorted(set(values))
                expected = list(range(1, max(ordered, default=0) + 1))
                if ordered != expected:
                    issues.append(
                        {"severity": "error", "code": "figure-numbering-gap", "chapter": chapter, "actual": ordered, "expected": expected}
                    )

            for caption_identifier in sorted(set(captions) - references):
                issues.append({"severity": "warning", "code": "figure-caption-not-referenced-in-body", "caption_id": caption_identifier})
            for reference_identifier in sorted(references - set(captions)):
                issues.append({"severity": "error", "code": "figure-reference-without-caption", "caption_id": reference_identifier})

    except (ValueError, zipfile.BadZipFile, ET.ParseError) as exc:
        parser.error(f"Unable to audit images: {exc}")

    summary = {
        "image_count": len(records),
        "caption_count": len(captions),
        "error_count": sum(item["severity"] == "error" for item in issues),
        "warning_count": sum(item["severity"] == "warning" for item in issues),
    }
    report = {
        "document": str(args.docx.resolve()),
        "matched_boundary_heading": matched_boundary,
        "minimum_dpi": args.min_dpi,
        "summary": summary,
        "images": records,
        "issues": issues,
    }
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[AUDIT] images={summary['image_count']} captions={summary['caption_count']} errors={summary['error_count']} warnings={summary['warning_count']}")
    for item in issues:
        print(f"  [{item['severity'].upper()}] {item['code']}")
    if args.fail_on == "error" and summary["error_count"]:
        return 1
    if args.fail_on == "warning" and (summary["error_count"] or summary["warning_count"]):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
