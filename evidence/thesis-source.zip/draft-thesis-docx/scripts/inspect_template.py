#!/usr/bin/env python3
"""Inspect a DOCX template using only the Python standard library."""

from __future__ import annotations

import argparse
import json
import zipfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def attr(element: ET.Element | None, name: str) -> str | None:
    return None if element is None else element.get(f"{W}{name}")


def paragraph_text(paragraph: ET.Element) -> str:
    return "".join(node.text or "" for node in paragraph.iter(f"{W}t")).strip()


def paragraph_style(paragraph: ET.Element) -> str:
    return attr(paragraph.find(f"{W}pPr/{W}pStyle"), "val") or "(inherited)"


def parse_xml(archive: zipfile.ZipFile, name: str) -> ET.Element:
    return ET.fromstring(archive.read(name))


def inspect(docx_path: Path) -> dict[str, object]:
    with zipfile.ZipFile(docx_path) as archive:
        names = set(archive.namelist())
        document = parse_xml(archive, "word/document.xml")
        paragraphs = document.findall(f".//{W}body/{W}p")
        tables = document.findall(f".//{W}body/{W}tbl")
        sections = document.findall(f".//{W}sectPr")
        style_counts = Counter(paragraph_style(paragraph) for paragraph in paragraphs)

        styles = []
        if "word/styles.xml" in names:
            style_root = parse_xml(archive, "word/styles.xml")
            for style in style_root.findall(f"{W}style"):
                styles.append(
                    {
                        "type": attr(style, "type"),
                        "id": attr(style, "styleId"),
                        "name": attr(style.find(f"{W}name"), "val"),
                    }
                )

        preview = []
        for index, paragraph in enumerate(paragraphs, start=1):
            text = paragraph_text(paragraph)
            if text:
                preview.append(
                    {"paragraph": index, "style": paragraph_style(paragraph), "text": text[:160]}
                )

        headers = sorted(name for name in names if name.startswith("word/header") and name.endswith(".xml"))
        footers = sorted(name for name in names if name.startswith("word/footer") and name.endswith(".xml"))

    return {
        "file": str(docx_path.resolve()),
        "paragraph_count": len(paragraphs),
        "table_count": len(tables),
        "section_count": len(sections),
        "headers": headers,
        "footers": footers,
        "paragraph_style_counts": dict(sorted(style_counts.items())),
        "defined_styles": styles,
        "non_empty_paragraph_preview": preview,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path, help="Path to the DOCX template")
    parser.add_argument("--out-json", type=Path, help="Optional output JSON path")
    args = parser.parse_args()

    if not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")

    try:
        report = inspect(args.docx)
    except (KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        parser.error(f"Unable to inspect DOCX: {exc}")

    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.write_text(rendered + "\n", encoding="utf-8")
        print(f"[OK] Wrote template report: {args.out_json}")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
