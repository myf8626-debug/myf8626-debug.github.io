#!/usr/bin/env python3
"""Render DOCX to page PNGs on Windows with auto-detected LibreOffice and Poppler."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path


def first_existing(candidates: list[Path | None]) -> Path | None:
    for candidate in candidates:
        if candidate and candidate.is_file():
            return candidate.resolve()
    return None


def detect_soffice(explicit: Path | None) -> Path:
    appdata = Path(os.environ.get("APPDATA", ""))
    candidates = [
        explicit,
        Path(os.environ["SOFFICE_PATH"]) if os.environ.get("SOFFICE_PATH") else None,
        Path(shutil.which("soffice.exe") or shutil.which("soffice") or "")
        if shutil.which("soffice.exe") or shutil.which("soffice")
        else None,
        Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
        / "LibreOffice/program/soffice.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))
        / "LibreOffice/program/soffice.exe",
        appdata
        / "Trae CN/ModularData/ai-agent/vm/tools/app/libreoffice/App/libreoffice/program/soffice.exe",
    ]
    soffice = first_existing(candidates)
    if soffice is None:
        raise FileNotFoundError(
            "LibreOffice soffice.exe was not found. Set SOFFICE_PATH or use --soffice."
        )
    return soffice


def detect_pdftoppm(explicit: Path | None) -> Path:
    appdata = Path(os.environ.get("APPDATA", ""))
    found = shutil.which("pdftoppm.exe") or shutil.which("pdftoppm")
    candidates = [
        explicit,
        Path(os.environ["PDFTOPPM_PATH"]) if os.environ.get("PDFTOPPM_PATH") else None,
        Path(found) if found else None,
        appdata / "Trae CN/ModularData/ai-agent/vm/tools/bin/pdftoppm.cmd",
        appdata / "Trae CN/ModularData/ai-agent/vm/tools/app/poppler/pdftoppm.exe",
    ]
    pdftoppm = first_existing(candidates)
    if pdftoppm is None:
        raise FileNotFoundError(
            "Poppler pdftoppm was not found. Set PDFTOPPM_PATH or use --pdftoppm."
        )
    return pdftoppm


def run_pdftoppm(pdftoppm: Path, args: list[str]) -> None:
    if pdftoppm.suffix.lower() in {".cmd", ".bat"}:
        command = [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(pdftoppm), *args]
    else:
        command = [str(pdftoppm), *args]
    subprocess.run(command, check=True)


def wait_for_file(path: Path, timeout_seconds: int) -> None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if path.is_file() and path.stat().st_size:
            return
        time.sleep(0.5)
    raise TimeoutError(f"Timed out waiting for rendered PDF: {path}")


def render(
    input_docx: Path,
    output_dir: Path,
    soffice: Path,
    pdftoppm: Path,
    dpi: int,
    timeout_seconds: int,
    emit_pdf: bool,
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = output_dir / f"{input_docx.stem}.pdf"
    page_prefix = output_dir / "page"
    if pdf_path.exists():
        pdf_path.unlink()
    for old_page in output_dir.glob("page-*.png"):
        old_page.unlink()

    profile_dir = Path(tempfile.mkdtemp(prefix="codex-lo-thesis-"))
    try:
        subprocess.run(
            [
                str(soffice),
                "--headless",
                f"-env:UserInstallation={profile_dir.as_uri()}",
                "--convert-to",
                "pdf",
                "--outdir",
                str(output_dir),
                str(input_docx),
            ],
            check=False,
            timeout=timeout_seconds,
        )
        wait_for_file(pdf_path, timeout_seconds)
        run_pdftoppm(
            pdftoppm, ["-png", "-r", str(dpi), str(pdf_path), str(page_prefix)]
        )
        pages = sorted(output_dir.glob("page-*.png"))
        if not pages:
            raise RuntimeError("pdftoppm completed without creating page PNGs.")
        if not emit_pdf:
            pdf_path.unlink(missing_ok=True)
        return pages
    finally:
        shutil.rmtree(profile_dir, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path, help="DOCX file to render")
    parser.add_argument("--output-dir", type=Path, required=True, help="PNG output directory")
    parser.add_argument("--soffice", type=Path, help="Optional soffice.exe override")
    parser.add_argument("--pdftoppm", type=Path, help="Optional pdftoppm override")
    parser.add_argument("--dpi", type=int, default=130, help="Raster DPI; default: 130")
    parser.add_argument("--timeout", type=int, default=120, help="Timeout seconds")
    parser.add_argument("--emit-pdf", action="store_true", help="Keep the intermediate PDF")
    args = parser.parse_args()
    if not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")

    try:
        soffice = detect_soffice(args.soffice)
        pdftoppm = detect_pdftoppm(args.pdftoppm)
        pages = render(
            args.docx.resolve(),
            args.output_dir.resolve(),
            soffice,
            pdftoppm,
            args.dpi,
            args.timeout,
            args.emit_pdf,
        )
    except (FileNotFoundError, RuntimeError, subprocess.SubprocessError, TimeoutError) as exc:
        parser.error(str(exc))

    print(f"[OK] soffice: {soffice}")
    print(f"[OK] pdftoppm: {pdftoppm}")
    print(f"[OK] rendered pages: {len(pages)}")
    print(f"[OK] output directory: {args.output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
