#!/usr/bin/env python3
"""Replace thesis title text in main-body headers without editing protected front matter."""

from __future__ import annotations

import argparse
import json
import posixpath
import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from verify_frontmatter_unchanged import W, normalize_heading

R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PR = "{http://schemas.openxmlformats.org/package/2006/relationships}"
CT = "{http://schemas.openxmlformats.org/package/2006/content-types}"
HEADER_REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header"
HEADER_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"


def paragraph_text(paragraph: ET.Element) -> str:
    return "".join(node.text or "" for node in paragraph.iter(f"{W}t")).strip()


def sect_pr_for_child(child: ET.Element) -> ET.Element | None:
    if child.tag == f"{W}sectPr":
        return child
    if child.tag == f"{W}p":
        return child.find(f"{W}pPr/{W}sectPr")
    return None


def relationship_map(root: ET.Element) -> dict[str, ET.Element]:
    return {item.get("Id", ""): item for item in root.findall(f"{PR}Relationship")}


def next_relationship_id(rels_root: ET.Element) -> str:
    numbers = [
        int(match.group(1))
        for item in rels_root.findall(f"{PR}Relationship")
        if (match := re.fullmatch(r"rId(\d+)", item.get("Id", "")))
    ]
    return f"rId{max(numbers, default=0) + 1}"


def next_header_target(names: set[str]) -> str:
    numbers = [
        int(match.group(1))
        for name in names
        if (match := re.fullmatch(r"word/header(\d+)\.xml", name))
    ]
    return f"word/header{max(numbers, default=0) + 1}.xml"


def replace_text(payload: bytes, old_titles: list[str], new_title: str) -> tuple[bytes, int]:
    root = ET.fromstring(payload)
    replacements = 0
    for node in root.iter(f"{W}t"):
        text = node.text or ""
        for old_title in old_titles:
            if old_title and old_title in text:
                count = text.count(old_title)
                text = text.replace(old_title, new_title)
                replacements += count
        node.text = text
    return ET.tostring(root, encoding="utf-8", xml_declaration=True), replacements


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_docx", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--new-title", required=True)
    parser.add_argument("--old-title", action="append", default=[])
    parser.add_argument("--body-start-text", default="1 绪论")
    parser.add_argument("--out-json", type=Path)
    args = parser.parse_args()
    if not args.input_docx.is_file():
        parser.error(f"DOCX not found: {args.input_docx}")
    if args.input_docx.resolve() == args.out.resolve():
        parser.error("--out must differ from the input file")
    old_titles = [*args.old_title, "论文题目"]

    try:
        with zipfile.ZipFile(args.input_docx) as source:
            payloads = {item.filename: source.read(item.filename) for item in source.infolist()}
            infos = {item.filename: item for item in source.infolist()}
    except zipfile.BadZipFile as exc:
        parser.error(f"Unable to open DOCX: {exc}")

    document = ET.fromstring(payloads["word/document.xml"])
    body = document.find(f"{W}body")
    if body is None:
        parser.error("word/document.xml does not contain a body element")
    children = list(body)
    normalized_start = normalize_heading(args.body_start_text)
    body_start_index = next(
        (
            index
            for index, child in enumerate(children)
            if child.tag == f"{W}p"
            and normalize_heading(paragraph_text(child)).startswith(normalized_start)
        ),
        None,
    )
    if body_start_index is None:
        parser.error(f"Unable to locate main-body heading: {args.body_start_text!r}")

    rels_root = ET.fromstring(payloads["word/_rels/document.xml.rels"])
    rels = relationship_map(rels_root)
    content_types = ET.fromstring(payloads["[Content_Types].xml"])
    names = set(payloads)
    sections = []
    section_start = 0
    effective_default_rid = None
    for child_index, child in enumerate(children):
        sect_pr = sect_pr_for_child(child)
        if sect_pr is None:
            continue
        default_ref = next(
            (
                ref
                for ref in sect_pr.findall(f"{W}headerReference")
                if ref.get(f"{W}type", "default") == "default"
            ),
            None,
        )
        explicit_rid = default_ref.get(f"{R}id") if default_ref is not None else None
        if explicit_rid:
            effective_default_rid = explicit_rid
        sections.append(
            {
                "number": len(sections) + 1,
                "start": section_start,
                "end": child_index,
                "sect_pr": sect_pr,
                "default_ref": default_ref,
                "explicit_rid": explicit_rid,
                "effective_rid": effective_default_rid,
            }
        )
        section_start = child_index + 1

    selected = [section for section in sections if section["end"] >= body_start_index]
    unselected_targets = {
        posixpath.normpath(posixpath.join("word", rels[section["effective_rid"]].get("Target", "")))
        for section in sections
        if section not in selected and section["effective_rid"] in rels
    }
    changed_parts = set()
    cloned_parts = []
    section_reports = []

    for section in selected:
        effective_rid = section["effective_rid"]
        if not effective_rid or effective_rid not in rels:
            section_reports.append({"section": section["number"], "status": "skipped-no-default-header"})
            continue
        source_target = posixpath.normpath(posixpath.join("word", rels[effective_rid].get("Target", "")))
        if source_target not in payloads:
            section_reports.append({"section": section["number"], "status": "skipped-missing-header-part"})
            continue

        needs_clone = section["explicit_rid"] is None or source_target in unselected_targets
        target_part = source_target
        target_rid = section["explicit_rid"]
        if needs_clone:
            target_part = next_header_target(names)
            names.add(target_part)
            payloads[target_part] = payloads[source_target]
            target_rid = next_relationship_id(rels_root)
            relationship = ET.SubElement(rels_root, f"{PR}Relationship")
            relationship.set("Id", target_rid)
            relationship.set("Type", HEADER_REL_TYPE)
            relationship.set("Target", posixpath.basename(target_part))
            rels[target_rid] = relationship
            header_ref = ET.Element(f"{W}headerReference")
            header_ref.set(f"{W}type", "default")
            header_ref.set(f"{R}id", target_rid)
            section["sect_pr"].insert(0, header_ref)
            override = ET.SubElement(content_types, f"{CT}Override")
            override.set("PartName", f"/{target_part}")
            override.set("ContentType", HEADER_CONTENT_TYPE)
            cloned_parts.append({"from": source_target, "to": target_part, "section": section["number"]})

        updated, replacements = replace_text(payloads[target_part], old_titles, args.new_title)
        payloads[target_part] = updated
        if replacements:
            changed_parts.add(target_part)
        section_reports.append(
            {
                "section": section["number"],
                "status": "updated" if replacements else "review-no-title-match",
                "header_part": target_part,
                "replacements": replacements,
            }
        )

    payloads["word/document.xml"] = ET.tostring(document, encoding="utf-8", xml_declaration=True)
    payloads["word/_rels/document.xml.rels"] = ET.tostring(rels_root, encoding="utf-8", xml_declaration=True)
    payloads["[Content_Types].xml"] = ET.tostring(content_types, encoding="utf-8", xml_declaration=True)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, "w") as target:
        for name, payload in payloads.items():
            target.writestr(infos.get(name, name), payload)

    report = {
        "input": str(args.input_docx.resolve()),
        "output": str(args.out.resolve()),
        "body_start_text": args.body_start_text,
        "body_start_child_index": body_start_index,
        "new_title": args.new_title,
        "changed_header_parts": sorted(changed_parts),
        "cloned_header_parts": cloned_parts,
        "sections": section_reports,
    }
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[OK] wrote body-header-synchronized copy: {args.out.resolve()}")
    print(f"[OK] changed header parts: {len(changed_parts)}; cloned parts: {len(cloned_parts)}")
    for section in section_reports:
        print(f"  section {section['section']}: {section['status']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
