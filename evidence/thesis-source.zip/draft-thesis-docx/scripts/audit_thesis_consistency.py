#!/usr/bin/env python3
"""Audit thesis DOCX terminology, placeholders, captions, and evidence claims."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

from verify_frontmatter_unchanged import W, element_text, find_boundary

FIGURE_PATTERN = re.compile(r"图\s*(\d+)\s*[-－—.]\s*(\d+)")
TABLE_PATTERN = re.compile(r"表\s*(\d+)\s*[-－—.]\s*(\d+)")
PLACEHOLDER_PATTERN = re.compile(
    r"(?:TODO|TBD|FIXME|XXX+|待补充|待完善|待核验|论文题目)", re.IGNORECASE
)
EVIDENCE_REVIEW_PATTERN = re.compile(
    r"(?:测试结果表明|实验结果表明|统计结果(?:与|和).{0,18}(?:一致|吻合)|"
    r"运行稳定|均通过测试|全部通过)"
)
UNVERIFIED_MARKER_PATTERN = re.compile(
    r"(?:待实际测试验证|待核验|尚未进行实际测试|需要结合实际测试记录验证)"
)


def paragraph_texts(root: ET.Element) -> list[str]:
    return [
        element_text(paragraph)
        for paragraph in root.iter(f"{W}p")
        if element_text(paragraph)
    ]


def package_texts(archive: zipfile.ZipFile, prefix: str) -> dict[str, list[str]]:
    result = {}
    for part in archive.namelist():
        if part.startswith(prefix) and part.endswith(".xml"):
            try:
                result[part] = paragraph_texts(ET.fromstring(archive.read(part)))
            except ET.ParseError:
                continue
    return result


def location_records(texts: list[str], source: str) -> list[dict[str, object]]:
    return [
        {"source": source, "paragraph": index, "text": text}
        for index, text in enumerate(texts, start=1)
    ]


def caption_key(match: re.Match[str], prefix: str) -> str:
    return f"{prefix}{match.group(1)}-{match.group(2)}"


def audit_captions(
    body_records: list[dict[str, object]], pattern: re.Pattern[str], prefix: str
) -> dict[str, object]:
    captions = []
    references = []
    for record in body_records:
        text = str(record["text"])
        matches = list(pattern.finditer(text))
        if not matches:
            continue
        if pattern.match(text.strip()):
            captions.append({**record, "id": caption_key(matches[0], prefix)})
        else:
            references.extend(
                {**record, "id": caption_key(match, prefix)} for match in matches
            )

    caption_counts = Counter(record["id"] for record in captions)
    caption_ids = set(caption_counts)
    reference_ids = {record["id"] for record in references}
    return {
        "captions": captions,
        "references": references,
        "duplicate_captions": sorted(
            caption for caption, count in caption_counts.items() if count > 1
        ),
        "referenced_without_caption": sorted(reference_ids - caption_ids),
        "captions_without_body_reference": sorted(caption_ids - reference_ids),
    }


def issue(severity: str, code: str, message: str, **details: object) -> dict[str, object]:
    return {"severity": severity, "code": code, "message": message, **details}


def inspect_docx(
    docx_path: Path,
    boundary_text: str | None,
    canonical_title: str | None,
    legacy_terms: list[str],
    test_records: list[Path],
) -> dict[str, object]:
    with zipfile.ZipFile(docx_path) as archive:
        document = ET.fromstring(archive.read("word/document.xml"))
        body = document.find(f"{W}body")
        if body is None:
            raise ValueError("word/document.xml does not contain a body element")
        boundary_index, matched_boundary, _, _ = find_boundary(body, boundary_text)
        editable_root = ET.Element(f"{W}body")
        for child in list(body)[boundary_index:]:
            editable_root.append(child)

        body_records = location_records(paragraph_texts(editable_root), "editable-body")
        header_records = [
            record
            for part, texts in package_texts(archive, "word/header").items()
            for record in location_records(texts, part)
        ]
        footer_records = [
            record
            for part, texts in package_texts(archive, "word/footer").items()
            for record in location_records(texts, part)
        ]
        scan_records = body_records + header_records + footer_records
        figures = audit_captions(body_records, FIGURE_PATTERN, "图")
        tables = audit_captions(body_records, TABLE_PATTERN, "表")
        issues = []

        for term in legacy_terms:
            matches = [
                record for record in scan_records if term and term in str(record["text"])
            ]
            if matches:
                issues.append(
                    issue(
                        "error",
                        "legacy-term",
                        f"Legacy term remains: {term}",
                        term=term,
                        occurrences=matches,
                    )
                )

        placeholder_matches = [
            record
            for record in scan_records
            if PLACEHOLDER_PATTERN.search(str(record["text"]))
        ]
        if placeholder_matches:
            issues.append(
                issue(
                    "warning",
                    "placeholder-text",
                    "Placeholder-like text requires review.",
                    occurrences=placeholder_matches,
                )
            )

        evidence_matches = [
            record
            for record in body_records
            if EVIDENCE_REVIEW_PATTERN.search(str(record["text"]))
            and not UNVERIFIED_MARKER_PATTERN.search(str(record["text"]))
        ]
        if evidence_matches:
            if test_records:
                issues.append(
                    issue(
                        "warning",
                        "evidence-claim-manual-link-review",
                        "Test records were supplied. Manually confirm that each claim is supported by those records.",
                        supplied_test_records=[str(path.resolve()) for path in test_records],
                        occurrences=evidence_matches,
                    )
                )
            else:
                issues.append(
                    issue(
                        "error",
                        "evidence-claim-without-test-record",
                        "Test or statistical-result claims require user-provided test records or an explicit unverified marker such as 待实际测试验证.",
                        occurrences=evidence_matches,
                    )
                )

        for label, audit in (("figure", figures), ("table", tables)):
            if audit["duplicate_captions"]:
                issues.append(
                    issue(
                        "error",
                        f"duplicate-{label}-caption",
                        f"Duplicate {label} captions found.",
                        ids=audit["duplicate_captions"],
                    )
                )
            if audit["referenced_without_caption"]:
                issues.append(
                    issue(
                        "error",
                        f"missing-{label}-caption",
                        f"{label.title()} references without matching captions found.",
                        ids=audit["referenced_without_caption"],
                    )
                )
            if audit["captions_without_body_reference"]:
                issues.append(
                    issue(
                        "warning",
                        f"uncited-{label}-caption",
                        f"{label.title()} captions without a body reference require review.",
                        ids=audit["captions_without_body_reference"],
                    )
                )

        if canonical_title:
            title_locations = [
                record
                for record in body_records + header_records
                if canonical_title in str(record["text"])
            ]
            if not title_locations:
                issues.append(
                    issue(
                        "warning",
                        "canonical-title-not-found",
                        "Canonical title was not found in editable body or headers.",
                        canonical_title=canonical_title,
                    )
                )
        else:
            title_locations = []

        return {
            "document": str(docx_path.resolve()),
            "matched_boundary_heading": matched_boundary,
            "canonical_title": canonical_title,
            "canonical_title_locations": title_locations,
            "legacy_terms": legacy_terms,
            "supplied_test_records": [str(path.resolve()) for path in test_records],
            "summary": {
                "editable_paragraph_count": len(body_records),
                "header_paragraph_count": len(header_records),
                "footer_paragraph_count": len(footer_records),
                "embedded_media_count": sum(
                    1 for part in archive.namelist() if part.startswith("word/media/")
                ),
                "word_table_count": len(list(editable_root.iter(f"{W}tbl"))),
                "figure_caption_count": len(figures["captions"]),
                "table_caption_count": len(tables["captions"]),
                "error_count": sum(item["severity"] == "error" for item in issues),
                "warning_count": sum(item["severity"] == "warning" for item in issues),
            },
            "figures": figures,
            "tables": tables,
            "issues": issues,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path, help="DOCX thesis to audit")
    parser.add_argument("--boundary-text", help="Editable boundary heading; defaults to abstract")
    parser.add_argument("--canonical-title", help="Expected thesis title")
    parser.add_argument(
        "--legacy-term", action="append", default=[], help="Disallowed stale term; repeat as needed"
    )
    parser.add_argument(
        "--test-record",
        action="append",
        type=Path,
        default=[],
        help="User-provided test record file; repeat as needed",
    )
    parser.add_argument("--out-json", type=Path, help="Optional JSON report path")
    parser.add_argument(
        "--fail-on",
        choices=("error", "warning", "never"),
        default="error",
        help="Exit non-zero threshold; default: error",
    )
    args = parser.parse_args()
    if not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")
    missing_test_records = [path for path in args.test_record if not path.is_file()]
    if missing_test_records:
        parser.error(f"Test record not found: {missing_test_records[0]}")

    try:
        report = inspect_docx(
            args.docx, args.boundary_text, args.canonical_title, args.legacy_term, args.test_record
        )
    except (ValueError, zipfile.BadZipFile, ET.ParseError) as exc:
        parser.error(f"Unable to audit DOCX: {exc}")

    output = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(output + "\n", encoding="utf-8")

    summary = report["summary"]
    print(
        "[AUDIT] "
        f"errors={summary['error_count']} warnings={summary['warning_count']} "
        f"figures={summary['figure_caption_count']} tables={summary['table_caption_count']} "
        f"media={summary['embedded_media_count']}"
    )
    for item in report["issues"]:
        print(f"  [{item['severity'].upper()}] {item['code']}: {item['message']}")

    if args.fail_on == "error" and summary["error_count"]:
        return 1
    if args.fail_on == "warning" and (summary["error_count"] or summary["warning_count"]):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
