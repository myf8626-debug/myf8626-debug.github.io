#!/usr/bin/env python3
"""Validate a thesis reference inventory and optionally audit DOCX numeric citations."""

from __future__ import annotations

import argparse
import csv
import json
import re
import socket
import zipfile
from datetime import date, datetime
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from xml.etree import ElementTree as ET

REQUIRED_COLUMNS = {
    "title",
    "authors",
    "year",
    "source",
    "identifier",
    "url",
    "verified_on",
    "is_classic",
    "classic_reason",
    "supports",
}
TRUE_VALUES = {"1", "true", "yes", "y"}
FALSE_VALUES = {"", "0", "false", "no", "n"}
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
DOI_PATTERN = re.compile(r"^(?:doi:\s*|https?://doi\.org/)?(10\.\d{4,9}/\S+)$", re.IGNORECASE)
CITATION_BLOCK_PATTERN = re.compile(r"\[(\d+(?:\s*[-,，]\s*\d+)*)\]")
BIBLIOGRAPHY_ENTRY_PATTERN = re.compile(r"^\s*\[(\d+)\]")


def valid_url(value: str) -> bool:
    if not value:
        return True
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def parse_date(value: str) -> bool:
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        return False
    return True


def expand_numeric_block(value: str) -> set[int]:
    result = set()
    for item in re.split(r"[,，]", value):
        item = item.strip()
        if "-" in item:
            start_text, end_text = (part.strip() for part in item.split("-", 1))
            if start_text.isdigit() and end_text.isdigit():
                start, end = int(start_text), int(end_text)
                if start <= end and end - start <= 100:
                    result.update(range(start, end + 1))
        elif item.isdigit():
            result.add(int(item))
    return result


def paragraph_text(paragraph: ET.Element) -> str:
    return "".join(node.text or "" for node in paragraph.iter(f"{W}t")).strip()


def audit_docx_numeric_citations(docx_path: Path) -> dict[str, object]:
    with zipfile.ZipFile(docx_path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    texts = [paragraph_text(paragraph) for paragraph in root.iter(f"{W}p")]
    bibliography_index = next(
        (index for index, text in enumerate(texts) if re.sub(r"\s+", "", text) == "参考文献"),
        None,
    )
    body_texts = texts if bibliography_index is None else texts[:bibliography_index]
    bibliography_texts = [] if bibliography_index is None else texts[bibliography_index + 1:]
    cited_numbers = {
        number
        for text in body_texts
        for match in CITATION_BLOCK_PATTERN.finditer(text)
        for number in expand_numeric_block(match.group(1))
    }
    bibliography_numbers = {
        int(match.group(1))
        for text in bibliography_texts
        if (match := BIBLIOGRAPHY_ENTRY_PATTERN.match(text))
    }
    return {
        "bibliography_heading_found": bibliography_index is not None,
        "body_citation_numbers": sorted(cited_numbers),
        "bibliography_numbers": sorted(bibliography_numbers),
        "body_citations_without_bibliography_entry": sorted(cited_numbers - bibliography_numbers),
        "bibliography_entries_not_cited_in_body": sorted(bibliography_numbers - cited_numbers),
    }


def check_url_reachable(url: str, timeout: float) -> tuple[bool, str]:
    if not url:
        return False, "missing URL"
    for method in ("HEAD", "GET"):
        try:
            request = Request(url, method=method, headers={"User-Agent": "draft-thesis-docx-audit/1.0"})
            with urlopen(request, timeout=timeout) as response:
                return 200 <= response.status < 400, f"HTTP {response.status}"
        except HTTPError as exc:
            if exc.code in {403, 405} and method == "HEAD":
                continue
            return False, f"HTTP {exc.code}"
        except (URLError, TimeoutError, socket.timeout) as exc:
            if method == "HEAD":
                continue
            return False, str(exc.reason if isinstance(exc, URLError) else exc)
    return False, "unreachable"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_file", type=Path, help="UTF-8 reference inventory CSV")
    parser.add_argument("--as-of", default=date.today().isoformat(), help="YYYY-MM-DD; defaults to today")
    parser.add_argument("--recent-years", type=int, default=5, help="Recent calendar-year window")
    parser.add_argument("--min-recent-ratio", type=float, default=0.6, help="Warn below this recent-source ratio")
    parser.add_argument("--docx", type=Path, help="Optional thesis DOCX for numeric citation cross-check")
    parser.add_argument("--check-links", action="store_true", help="Attempt HTTP verification for URLs and DOI URLs")
    parser.add_argument("--link-timeout", type=float, default=8.0)
    parser.add_argument("--out-json", type=Path)
    args = parser.parse_args()

    if not args.csv_file.is_file():
        parser.error(f"CSV not found: {args.csv_file}")
    if not parse_date(args.as_of):
        parser.error("--as-of must be YYYY-MM-DD")
    if args.recent_years < 0:
        parser.error("--recent-years must be non-negative")
    if not 0 <= args.min_recent_ratio <= 1:
        parser.error("--min-recent-ratio must be between 0 and 1")
    if args.docx and not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")

    cutoff_year = int(args.as_of[:4]) - args.recent_years
    errors: list[str] = []
    warnings: list[str] = []
    seen_titles: dict[str, int] = {}
    seen_identifiers: dict[str, int] = {}
    link_checks = []
    recent_count = 0

    with args.csv_file.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = set(reader.fieldnames or [])
        missing = sorted(REQUIRED_COLUMNS - columns)
        if missing:
            errors.append(f"missing columns: {', '.join(missing)}")
        rows = list(reader)

    for row_number, row in enumerate(rows, start=2):
        def value(key: str) -> str:
            return (row.get(key) or "").strip()

        for key in ("title", "authors", "year", "source", "verified_on", "supports"):
            if not value(key):
                errors.append(f"row {row_number}: {key} is required")

        try:
            year = int(value("year"))
        except ValueError:
            errors.append(f"row {row_number}: year must be an integer")
            year = None

        if value("verified_on") and not parse_date(value("verified_on")):
            errors.append(f"row {row_number}: verified_on must be YYYY-MM-DD")

        if not value("identifier") and not value("url"):
            errors.append(f"row {row_number}: identifier or url is required")
        if not valid_url(value("url")):
            errors.append(f"row {row_number}: url must use http or https")
        identifier = value("identifier")
        doi_match = DOI_PATTERN.match(identifier)
        if identifier.lower().startswith(("doi:", "10.", "http://doi.org/", "https://doi.org/")) and not doi_match:
            errors.append(f"row {row_number}: DOI identifier format is invalid")

        classic_raw = value("is_classic").lower()
        if classic_raw not in TRUE_VALUES | FALSE_VALUES:
            errors.append(f"row {row_number}: is_classic must be true or false")
        is_classic = classic_raw in TRUE_VALUES
        if year is not None and year < cutoff_year:
            if not is_classic:
                errors.append(
                    f"row {row_number}: year {year} predates {cutoff_year}; mark as classic and justify it"
                )
            elif not value("classic_reason"):
                errors.append(f"row {row_number}: classic_reason is required for an older source")
            else:
                warnings.append(f"row {row_number}: older justified source retained ({year})")
        elif year is not None:
            recent_count += 1

        title_key = re.sub(r"\s+", "", value("title")).casefold()
        identifier_key = identifier.casefold()
        if title_key and title_key in seen_titles:
            errors.append(f"row {row_number}: duplicate title also appears in row {seen_titles[title_key]}")
        else:
            seen_titles[title_key] = row_number
        if identifier_key and identifier_key in seen_identifiers:
            errors.append(f"row {row_number}: duplicate identifier also appears in row {seen_identifiers[identifier_key]}")
        elif identifier_key:
            seen_identifiers[identifier_key] = row_number

        if args.check_links:
            check_target = value("url")
            if not check_target and doi_match:
                check_target = f"https://doi.org/{doi_match.group(1)}"
            reachable, detail = check_url_reachable(check_target, args.link_timeout)
            link_checks.append({"row": row_number, "url": check_target, "reachable": reachable, "detail": detail})
            if not reachable:
                warnings.append(f"row {row_number}: link verification failed ({detail})")

    recent_ratio = recent_count / len(rows) if rows else 0.0
    if rows and recent_ratio < args.min_recent_ratio:
        warnings.append(
            f"recent-source ratio {recent_ratio:.1%} is below requested minimum {args.min_recent_ratio:.1%}"
        )

    docx_audit = None
    if args.docx:
        try:
            docx_audit = audit_docx_numeric_citations(args.docx)
        except (zipfile.BadZipFile, ET.ParseError) as exc:
            errors.append(f"unable to audit DOCX citations: {exc}")
        else:
            if not docx_audit["bibliography_heading_found"]:
                errors.append("DOCX bibliography heading not found")
            if docx_audit["body_citations_without_bibliography_entry"]:
                errors.append(
                    "DOCX body citations without bibliography entries: "
                    + ", ".join(map(str, docx_audit["body_citations_without_bibliography_entry"]))
                )
            if docx_audit["bibliography_entries_not_cited_in_body"]:
                warnings.append(
                    "DOCX bibliography entries not cited in body: "
                    + ", ".join(map(str, docx_audit["bibliography_entries_not_cited_in_body"]))
                )

    report = {
        "csv_file": str(args.csv_file.resolve()),
        "as_of": args.as_of,
        "recent_year_cutoff": cutoff_year,
        "recent_source_ratio": recent_ratio,
        "minimum_recent_source_ratio": args.min_recent_ratio,
        "record_count": len(rows),
        "docx_citation_audit": docx_audit,
        "link_checks": link_checks,
        "errors": errors,
        "warnings": warnings,
    }
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    for warning in warnings:
        print(f"[WARN] {warning}")
    if errors:
        for error in errors:
            print(f"[FAIL] {error}")
        return 1

    print(f"[OK] Validated {len(rows)} reference record(s); recent-year cutoff is {cutoff_year}; recent ratio is {recent_ratio:.1%}.")
    print("[NOTE] Syntax and optional HTTP checks do not replace manual academic-database or full-text verification.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
