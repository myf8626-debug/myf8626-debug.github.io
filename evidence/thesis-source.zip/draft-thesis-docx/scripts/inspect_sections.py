#!/usr/bin/env python3
"""Inspect DOCX section breaks, page numbering, and header/footer references."""

from __future__ import annotations

import argparse
import json
import posixpath
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PR = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"w": W, "r": R, "pr": PR}


def qname(namespace: str, local: str) -> str:
    return f"{{{namespace}}}{local}"


def attr(element: ET.Element | None, namespace: str, local: str) -> str | None:
    if element is None:
        return None
    return element.get(qname(namespace, local))


def text_from_xml(data: bytes) -> str:
    root = ET.fromstring(data)
    parts = []
    for node in root.iter():
        if node.tag in {qname(W, "t"), qname(W, "instrText")} and node.text:
            parts.append(node.text)
    return " ".join(" ".join(parts).split())


def load_relationships(archive: zipfile.ZipFile) -> dict[str, str]:
    rels_path = "word/_rels/document.xml.rels"
    if rels_path not in archive.namelist():
        return {}
    root = ET.fromstring(archive.read(rels_path))
    return {
        relationship.get("Id", ""): relationship.get("Target", "")
        for relationship in root.findall("pr:Relationship", NS)
    }


def normalized_target(target: str) -> str:
    return posixpath.normpath(posixpath.join("word", target))


def reference_report(
    archive: zipfile.ZipFile,
    relationships: dict[str, str],
    sect_pr: ET.Element,
    reference_name: str,
) -> list[dict[str, str | None]]:
    report = []
    for reference in sect_pr.findall(f"w:{reference_name}", NS):
        relationship_id = attr(reference, R, "id")
        target = relationships.get(relationship_id or "")
        archive_target = normalized_target(target) if target else None
        content = None
        if archive_target and archive_target in archive.namelist():
            content = text_from_xml(archive.read(archive_target))
        report.append(
            {
                "type": attr(reference, W, "type") or "default",
                "relationship_id": relationship_id,
                "target": archive_target,
                "text_and_fields": content,
            }
        )
    return report


def inheritance_report(
    sect_pr: ET.Element, reference_name: str, section_number: int
) -> dict[str, bool]:
    explicit_types = {
        attr(reference, W, "type") or "default"
        for reference in sect_pr.findall(f"w:{reference_name}", NS)
    }
    return {
        reference_type: section_number > 1 and reference_type not in explicit_types
        for reference_type in ("default", "first", "even")
    }


def section_report(
    archive: zipfile.ZipFile,
    relationships: dict[str, str],
    sect_pr: ET.Element,
    location: str,
    number: int,
) -> dict[str, object]:
    pg_num_type = sect_pr.find("w:pgNumType", NS)
    section_type = sect_pr.find("w:type", NS)
    return {
        "section_number": number,
        "location": location,
        "break_type": attr(section_type, W, "val") or "nextPage",
        "page_number_format": attr(pg_num_type, W, "fmt"),
        "page_number_start": attr(pg_num_type, W, "start"),
        "different_first_page": sect_pr.find("w:titlePg", NS) is not None,
        "headers": reference_report(
            archive, relationships, sect_pr, "headerReference"
        ),
        "headers_inherit_from_previous": inheritance_report(
            sect_pr, "headerReference", number
        ),
        "footers": reference_report(
            archive, relationships, sect_pr, "footerReference"
        ),
        "footers_inherit_from_previous": inheritance_report(
            sect_pr, "footerReference", number
        ),
    }


def inspect_docx(docx_path: Path) -> dict[str, object]:
    with zipfile.ZipFile(docx_path) as archive:
        document = ET.fromstring(archive.read("word/document.xml"))
        relationships = load_relationships(archive)
        settings = (
            ET.fromstring(archive.read("word/settings.xml"))
            if "word/settings.xml" in archive.namelist()
            else None
        )
        body = document.find("w:body", NS)
        if body is None:
            raise ValueError("DOCX document.xml does not contain a body element.")

        section_properties: list[tuple[str, ET.Element]] = []
        for paragraph_index, paragraph in enumerate(body.findall("w:p", NS), start=1):
            sect_pr = paragraph.find("w:pPr/w:sectPr", NS)
            if sect_pr is not None:
                section_properties.append((f"paragraph:{paragraph_index}", sect_pr))
        final_sect_pr = body.find("w:sectPr", NS)
        if final_sect_pr is not None:
            section_properties.append(("body:final", final_sect_pr))

        sections = [
            section_report(archive, relationships, sect_pr, location, number)
            for number, (location, sect_pr) in enumerate(section_properties, start=1)
        ]
        return {
            "document": str(docx_path.resolve()),
            "even_and_odd_headers_enabled": (
                settings is not None
                and settings.find("w:evenAndOddHeaders", NS) is not None
            ),
            "linkage_note": (
                "For sections after the first, a missing explicit header/footer "
                "reference means Word inherits that reference type from the "
                "previous section."
            ),
            "section_count": len(sections),
            "sections": sections,
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path, help="DOCX file to inspect")
    parser.add_argument("--out-json", type=Path, help="Optional JSON output path")
    args = parser.parse_args()

    report = inspect_docx(args.docx)
    output = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(output + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
