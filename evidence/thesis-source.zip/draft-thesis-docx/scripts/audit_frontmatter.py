"""Machine-readable front-matter verification; never upgrades a legacy snapshot silently."""
import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path
from verify_frontmatter_unchanged import protected_digest

KEYS = ('normalized_boundary_text', 'protected_body_child_count', 'sha256',
        'protected_dependency_parts', 'protected_relationship_manifest_sha256',
        'protected_global_render_parts')

def audit(document, snapshot):
    expected = json.loads(Path(snapshot).read_text(encoding='utf-8'))
    if not isinstance(expected, dict) or expected.get('schema_version') != 2 or any(k not in expected for k in (*KEYS, 'boundary_text')):
        raise ValueError('A complete schema-version 2 snapshot is required; regenerate from the trusted original template.')
    actual = protected_digest(Path(document), expected['boundary_text'])
    changes = []
    for key in KEYS:
        if actual[key] != expected[key]:
            entry = {'check': key}
            if isinstance(actual[key], dict):
                entry['parts'] = [p for p in sorted(set(actual[key]) | set(expected[key])) if actual[key].get(p) != expected[key].get(p)]
            changes.append(entry)
    return {'schema_version': 1, 'status': 'blocked' if changes else 'passed',
            'document_sha256': hashlib.sha256(Path(document).read_bytes()).hexdigest(),
            'snapshot_sha256': hashlib.sha256(Path(snapshot).read_bytes()).hexdigest(),
            'boundary': actual['matched_boundary_text'], 'changes': changes,
            'limitations': ['Checks protected package content, not visual correctness or reference truth.',
                            'Does not imply validation on a real thesis.']}

def same_file(left, right):
    left, right = Path(left), Path(right)
    return left.resolve() == right.resolve() or (left.exists() and right.exists() and left.samefile(right))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('document', type=Path)
    parser.add_argument('--snapshot', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    if same_file(args.report, args.document) or same_file(args.report, args.snapshot):
        print('Report path aliases an input; refusing to overwrite the document or snapshot.', file=sys.stderr)
        return 2
    try:
        result = audit(args.document, args.snapshot)
    except Exception as error:
        result = {'schema_version': 1, 'status': 'error', 'error': type(error).__name__ + ': ' + str(error)}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    # A failed write must not truncate the previous report. Replace only after
    # the complete JSON has been written to a sibling temporary file.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=args.report.parent,
                                         prefix='.audit-', suffix='.tmp', delete=False) as output:
            temporary = output.name
            output.write(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
        os.replace(temporary, args.report)
    finally:
        if temporary and Path(temporary).exists():
            Path(temporary).unlink()
    print(result['status'])
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
