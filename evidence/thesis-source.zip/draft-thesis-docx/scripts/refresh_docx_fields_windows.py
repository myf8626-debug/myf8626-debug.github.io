#!/usr/bin/env python3
"""Prepare or immediately refresh DOCX TOC, PAGE, and NUMPAGES fields on Windows."""

from __future__ import annotations

import argparse
import base64
import shutil
import subprocess
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def mark_update_on_open(docx_path: Path) -> None:
    temporary = docx_path.with_suffix(".fields-temp.docx")
    with zipfile.ZipFile(docx_path, "r") as source, zipfile.ZipFile(temporary, "w") as target:
        for item in source.infolist():
            payload = source.read(item.filename)
            if item.filename == "word/settings.xml":
                root = ET.fromstring(payload)
                update = root.find(f"{W}updateFields")
                if update is None:
                    update = ET.SubElement(root, f"{W}updateFields")
                update.set(f"{W}val", "true")
                payload = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            target.writestr(item, payload)
    temporary.replace(docx_path)


def powershell_refresh_script(docx_path: Path) -> str:
    escaped = str(docx_path).replace("'", "''")
    return f"""
$ErrorActionPreference = 'Stop'
$path = '{escaped}'
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {{
  $doc = $word.Documents.Open($path, $false, $false)
  foreach ($toc in $doc.TablesOfContents) {{ $toc.Update() }}
  [void]$doc.Fields.Update()
  foreach ($section in $doc.Sections) {{
    foreach ($header in $section.Headers) {{ [void]$header.Range.Fields.Update() }}
    foreach ($footer in $section.Footers) {{ [void]$footer.Range.Fields.Update() }}
  }}
  $doc.Save()
  $doc.Close($false)
}} finally {{
  if ($doc) {{ try {{ $doc.Close($false) }} catch {{}} }}
  $word.Quit()
}}
"""


def refresh_with_word(docx_path: Path, timeout: int) -> None:
    encoded = base64.b64encode(powershell_refresh_script(docx_path).encode("utf-16le")).decode("ascii")
    subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded],
        check=True,
        timeout=timeout,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_docx", type=Path)
    parser.add_argument("--out", type=Path, required=True, help="Output DOCX; input is never overwritten")
    parser.add_argument(
        "--mode",
        choices=("mark-on-open", "word"),
        default="mark-on-open",
        help="mark-on-open is safe and deferred; word performs an immediate Microsoft Word COM refresh",
    )
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()
    if not args.input_docx.is_file():
        parser.error(f"DOCX not found: {args.input_docx}")
    if args.input_docx.resolve() == args.out.resolve():
        parser.error("--out must differ from the input file")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input_docx, args.out)
    try:
        mark_update_on_open(args.out)
        if args.mode == "word":
            refresh_with_word(args.out.resolve(), args.timeout)
    except (zipfile.BadZipFile, ET.ParseError, subprocess.SubprocessError, TimeoutError) as exc:
        parser.error(f"Unable to refresh fields: {exc}")
    if args.mode == "word":
        print("[OK] Word refreshed TOC, PAGE, NUMPAGES, header, and footer fields.")
    else:
        print("[OK] Marked fields for refresh when opened in Word.")
        print("[NOTE] Cached field results are not immediately recalculated in mark-on-open mode.")
    print(f"[OK] output: {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
