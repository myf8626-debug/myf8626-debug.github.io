#!/usr/bin/env python3
"""Snapshot or verify protected DOCX front matter before an editable boundary."""

from __future__ import annotations

import argparse
import hashlib
import json
import posixpath
import unicodedata
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PR = "{http://schemas.openxmlformats.org/package/2006/relationships}"
INVISIBLE_SPACES = {"\u200b", "\ufeff"}
ABSTRACT_BOUNDARY_ALIASES = {"摘要", "中文摘要", "内容摘要"}
GLOBAL_RENDER_PARTS = {
    "word/styles.xml",
    "word/numbering.xml",
    "word/settings.xml",
    "word/fontTable.xml",
    "word/webSettings.xml",
}


def element_text(element: ET.Element) -> str:
    return "".join(node.text or "" for node in element.iter(f"{W}t")).strip()


def normalize_heading(text: str) -> str:
    """Normalize title text without weakening matching into a body-text search."""
    normalized = unicodedata.normalize("NFKC", text)
    compact = "".join(
        character
        for character in normalized
        if not character.isspace() and character not in INVISIBLE_SPACES
    )
    return compact.rstrip(":：")


def boundary_aliases(boundary_text: str | None) -> tuple[str | None, set[str]]:
    if boundary_text is None:
        return None, {normalize_heading(alias) for alias in ABSTRACT_BOUNDARY_ALIASES}

    requested = normalize_heading(boundary_text)
    if requested in {normalize_heading(alias) for alias in ABSTRACT_BOUNDARY_ALIASES}:
        return requested, {normalize_heading(alias) for alias in ABSTRACT_BOUNDARY_ALIASES}
    return requested, {requested}


def find_boundary(
    body: ET.Element, boundary_text: str | None
) -> tuple[int, str, str, str]:
    requested, accepted = boundary_aliases(boundary_text)
    matches = []
    for index, child in enumerate(list(body)):
        if child.tag != f"{W}p":
            continue
        raw_text = element_text(child)
        normalized_text = normalize_heading(raw_text)
        if normalized_text in accepted:
            matches.append((index, raw_text, normalized_text))

    if not matches:
        requested_description = boundary_text or "automatic abstract-title detection"
        raise ValueError(
            "boundary heading not found as an exact normalized body paragraph: "
            f"{requested_description!r}"
        )

    if requested:
        for index, raw_text, normalized_text in matches:
            if normalized_text == requested:
                return index, raw_text, normalized_text, "explicit-normalized"

    index, raw_text, normalized_text = matches[0]
    return index, raw_text, normalized_text, "abstract-alias"


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def relationship_part_path(source_part: str) -> str:
    directory, filename = posixpath.split(source_part)
    return posixpath.join(directory, "_rels", f"{filename}.rels")


def referenced_relationship_ids(element: ET.Element) -> set[str]:
    relationship_attributes = {f"{R}id", f"{R}embed", f"{R}link"}
    return {
        value
        for node in element.iter()
        for key, value in node.attrib.items()
        if key in relationship_attributes
    }


def relationships_for_part(
    archive: zipfile.ZipFile, source_part: str
) -> dict[str, dict[str, str]]:
    rels_part = relationship_part_path(source_part)
    if rels_part not in archive.namelist():
        return {}
    root = ET.fromstring(archive.read(rels_part))
    return {
        relationship.get("Id", ""): {
            "id": relationship.get("Id", ""),
            "type": relationship.get("Type", ""),
            "target": relationship.get("Target", ""),
            "target_mode": relationship.get("TargetMode", "Internal"),
        }
        for relationship in root.findall(f"{PR}Relationship")
    }


def resolved_target(source_part: str, target: str) -> str:
    return posixpath.normpath(posixpath.join(posixpath.dirname(source_part), target))


def dependency_manifest(
    archive: zipfile.ZipFile, roots: list[ET.Element]
) -> tuple[dict[str, str], str]:
    archive_names = set(archive.namelist())
    queued = [
        ("word/document.xml", relationship_id)
        for root in roots
        for relationship_id in referenced_relationship_ids(root)
    ]
    visited = set()
    parts: dict[str, str] = {}
    relationships = []

    while queued:
        source_part, relationship_id = queued.pop()
        visit_key = (source_part, relationship_id)
        if visit_key in visited:
            continue
        visited.add(visit_key)
        relationship = relationships_for_part(archive, source_part).get(relationship_id)
        if relationship is None:
            relationships.append(
                {
                    "source_part": source_part,
                    "id": relationship_id,
                    "missing": True,
                }
            )
            continue

        record = {"source_part": source_part, **relationship}
        relationships.append(record)
        if relationship["target_mode"].lower() == "external":
            continue

        target_part = resolved_target(source_part, relationship["target"])
        if target_part not in archive_names:
            record["missing_target_part"] = target_part
            continue

        payload = archive.read(target_part)
        parts[target_part] = sha256_bytes(payload)
        if target_part.endswith(".xml"):
            try:
                target_root = ET.fromstring(payload)
            except ET.ParseError:
                continue
            queued.extend(
                (target_part, nested_relationship_id)
                for nested_relationship_id in referenced_relationship_ids(target_root)
            )

    relationships.sort(
        key=lambda item: (
            item.get("source_part", ""),
            item.get("id", ""),
            item.get("target", ""),
        )
    )
    relationship_payload = json.dumps(
        relationships, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return dict(sorted(parts.items())), sha256_bytes(relationship_payload)


def global_render_manifest(archive: zipfile.ZipFile) -> dict[str, str]:
    protected_parts = GLOBAL_RENDER_PARTS | {
        part for part in archive.namelist() if part.startswith("word/theme/")
    }
    return {
        part: sha256_bytes(archive.read(part))
        for part in sorted(protected_parts)
        if part in archive.namelist()
    }


def protected_digest(docx_path: Path, boundary_text: str | None) -> dict[str, object]:
    with zipfile.ZipFile(docx_path) as archive:
        document = ET.fromstring(archive.read("word/document.xml"))
        body = document.find(f"{W}body")
        if body is None:
            raise ValueError("word/document.xml does not contain a body element")

        boundary_index, matched_text, normalized_text, match_mode = find_boundary(
            body, boundary_text
        )
        protected_elements = list(body)[:boundary_index]
        protected = [
            ET.tostring(child, encoding="utf-8") for child in protected_elements
        ]
        dependency_parts, relationship_manifest_sha256 = dependency_manifest(
            archive, protected_elements
        )
        global_render_parts = global_render_manifest(archive)

    payload = b"\n".join(protected)
    return {
        "schema_version": 2,
        "boundary_text": boundary_text or matched_text,
        "matched_boundary_text": matched_text,
        "normalized_boundary_text": normalized_text,
        "boundary_match_mode": match_mode,
        "protected_body_child_count": len(protected),
        "sha256": sha256_bytes(payload),
        "protected_dependency_parts": dependency_parts,
        "protected_relationship_manifest_sha256": relationship_manifest_sha256,
        "protected_global_render_parts": global_render_parts,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path, help="DOCX file to snapshot or verify")
    parser.add_argument(
        "--boundary-text",
        help=(
            "First editable heading text, such as 摘要. Matching ignores spacing "
            "and accepts common Chinese abstract-title aliases. Omit to auto-detect "
            "an abstract heading."
        ),
    )
    parser.add_argument("--write-snapshot", type=Path, help="Write a new JSON snapshot")
    parser.add_argument("--snapshot", type=Path, help="Verify against an existing JSON snapshot")
    args = parser.parse_args()

    if not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")
    if bool(args.write_snapshot) == bool(args.snapshot):
        parser.error("choose exactly one of --write-snapshot or --snapshot")
    if args.write_snapshot and (
        args.write_snapshot.resolve() == args.docx.resolve()
        or (args.write_snapshot.exists() and args.write_snapshot.samefile(args.docx))
    ):
        parser.error("snapshot output aliases the input DOCX; refusing to overwrite it")

    if args.snapshot:
        expected = json.loads(args.snapshot.read_text(encoding="utf-8"))
        boundary_text = (
            args.boundary_text
            or expected.get("matched_boundary_text")
            or expected.get("boundary_text")
        )
    else:
        boundary_text = args.boundary_text

    try:
        actual = protected_digest(args.docx, boundary_text)
    except (KeyError, ValueError, zipfile.BadZipFile, ET.ParseError) as exc:
        parser.error(f"Unable to inspect DOCX: {exc}")

    if args.write_snapshot:
        args.write_snapshot.write_text(
            json.dumps(actual, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(f"[OK] Wrote protected front-matter snapshot: {args.write_snapshot}")
        print(
            "     matched boundary heading: "
            f"{actual['matched_boundary_text']!r} "
            f"(normalized: {actual['normalized_boundary_text']!r})"
        )
        return 0

    expected_normalized_boundary = expected.get("normalized_boundary_text")
    if expected_normalized_boundary is None:
        expected_boundary_text = expected.get("matched_boundary_text") or expected.get(
            "boundary_text", ""
        )
        expected_normalized_boundary = normalize_heading(expected_boundary_text)

    differences = []
    if expected_normalized_boundary != actual.get("normalized_boundary_text"):
        differences.append("normalized_boundary_text")
    for key in ("protected_body_child_count", "sha256"):
        if expected.get(key) != actual.get(key):
            differences.append(key)
    if expected.get("schema_version", 1) >= 2:
        for key in (
            "protected_dependency_parts",
            "protected_relationship_manifest_sha256",
            "protected_global_render_parts",
        ):
            if expected.get(key) != actual.get(key):
                differences.append(key)
    if differences:
        print("[FAIL] Protected front matter changed.")
        for key in differences:
            expected_value = (
                expected_normalized_boundary
                if key == "normalized_boundary_text"
                else expected.get(key)
            )
            print(f"  {key}: expected={expected_value!r} actual={actual.get(key)!r}")
        return 1

    print("[OK] Protected front matter is unchanged.")
    if expected.get("schema_version", 1) < 2:
        print(
            "     note: legacy snapshot verified body XML only; create a new "
            "snapshot to enable complete front-matter part hashing."
        )
    print(
        "     matched boundary heading: "
        f"{actual['matched_boundary_text']!r} "
        f"(normalized: {actual['normalized_boundary_text']!r})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
