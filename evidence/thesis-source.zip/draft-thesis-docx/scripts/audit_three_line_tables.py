#!/usr/bin/env python3
"""Audit Word tables against the default thesis three-line-table border rules."""

from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
NONE_VALUES = {None, "", "nil", "none"}


def border_info(border: ET.Element | None) -> dict[str, object]:
    if border is None:
        return {"value": None, "size_eighth_points": None, "points": None}
    size = border.get(f"{W}sz")
    numeric_size = int(size) if size and size.isdigit() else None
    return {
        "value": border.get(f"{W}val"),
        "size_eighth_points": numeric_size,
        "points": numeric_size / 8 if numeric_size is not None else None,
    }


def border(parent: ET.Element | None, name: str) -> ET.Element | None:
    return None if parent is None else parent.find(f"{W}{name}")


def visible(info: dict[str, object]) -> bool:
    return info["value"] not in NONE_VALUES


def expected_line(info: dict[str, object], eighth_points: int) -> bool:
    return visible(info) and info["size_eighth_points"] == eighth_points


def table_audit(table: ET.Element, number: int) -> dict[str, object]:
    rows = table.findall(f"{W}tr")
    tbl_borders = table.find(f"{W}tblPr/{W}tblBorders")
    table_border_map = {
        name: border_info(border(tbl_borders, name))
        for name in ("top", "left", "bottom", "right", "insideH", "insideV")
    }
    findings = []

    if not expected_line(table_border_map["top"], 12):
        findings.append("table top border must be 1.5 pt")
    if not expected_line(table_border_map["bottom"], 12):
        findings.append("table bottom border must be 1.5 pt")
    for name in ("left", "right", "insideV", "insideH"):
        if visible(table_border_map[name]):
            findings.append(f"table {name} border must be absent")

    header_bottoms = []
    cell_border_overrides = []
    for row_index, row in enumerate(rows):
        cells = row.findall(f"{W}tc")
        for cell_index, cell in enumerate(cells):
            tc_borders = cell.find(f"{W}tcPr/{W}tcBorders")
            cell_map = {
                name: border_info(border(tc_borders, name))
                for name in ("top", "left", "bottom", "right", "insideH", "insideV")
            }
            if row_index == 0:
                header_bottoms.append(cell_map["bottom"])
            for name in ("left", "right", "insideH", "insideV"):
                if visible(cell_map[name]):
                    cell_border_overrides.append(
                        {"row": row_index + 1, "cell": cell_index + 1, "border": name, **cell_map[name]}
                    )
            if row_index not in {0, len(rows) - 1} and visible(cell_map["bottom"]):
                cell_border_overrides.append(
                    {"row": row_index + 1, "cell": cell_index + 1, "border": "bottom", **cell_map["bottom"]}
                )
            if row_index > 0 and visible(cell_map["top"]):
                cell_border_overrides.append(
                    {"row": row_index + 1, "cell": cell_index + 1, "border": "top", **cell_map["top"]}
                )

    if not header_bottoms or not all(expected_line(item, 6) for item in header_bottoms):
        findings.append("every final header-row cell must have a 0.75 pt bottom separator")
    if cell_border_overrides:
        findings.append("table contains prohibited internal or vertical cell-border overrides")

    return {
        "table_number": number,
        "row_count": len(rows),
        "column_count": max((len(row.findall(f"{W}tc")) for row in rows), default=0),
        "table_borders": table_border_map,
        "header_bottom_borders": header_bottoms,
        "prohibited_cell_border_overrides": cell_border_overrides,
        "findings": findings,
        "passes": not findings,
    }


def inspect_docx(docx_path: Path) -> dict[str, object]:
    with zipfile.ZipFile(docx_path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    tables = [
        table_audit(table, number)
        for number, table in enumerate(root.iter(f"{W}tbl"), start=1)
    ]
    return {
        "document": str(docx_path.resolve()),
        "required_style": {
            "vertical_borders": "absent",
            "top_border_points": 1.5,
            "header_separator_points": 0.75,
            "bottom_border_points": 1.5,
            "other_internal_horizontal_borders": "absent",
        },
        "summary": {
            "table_count": len(tables),
            "passing_table_count": sum(table["passes"] for table in tables),
            "failing_table_count": sum(not table["passes"] for table in tables),
        },
        "tables": tables,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path)
    parser.add_argument("--out-json", type=Path)
    parser.add_argument("--fail-on-deviation", action="store_true")
    args = parser.parse_args()
    if not args.docx.is_file():
        parser.error(f"DOCX not found: {args.docx}")
    try:
        report = inspect_docx(args.docx)
    except (zipfile.BadZipFile, ET.ParseError) as exc:
        parser.error(f"Unable to inspect DOCX: {exc}")
    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        args.out_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    summary = report["summary"]
    print(
        f"[AUDIT] tables={summary['table_count']} "
        f"passing={summary['passing_table_count']} failing={summary['failing_table_count']}"
    )
    for table in report["tables"]:
        if not table["passes"]:
            print(f"  [FAIL] table {table['table_number']}: {'; '.join(table['findings'])}")
    return 1 if args.fail_on_deviation and summary["failing_table_count"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
