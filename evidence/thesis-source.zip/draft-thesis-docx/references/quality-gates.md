# Thesis DOCX quality gates

## Template integrity

- Work on a copy of the source file.
- Run the protected front-matter comparison after edits.
- Require a current complete front-matter snapshot. It must protect pre-abstract body XML, recursively referenced package parts such as images and header/footer dependencies, and global rendering parts such as styles, numbering, settings, fonts, and themes.
- Treat a protected hash difference as blocking until reviewed. Recreate legacy body-XML-only snapshots before editing.
- Capture and review the section report before edits and after final pagination.
- Confirm the cover, declarations, authorization pages, section breaks, headers, footers, and page numbering visually.
- Treat the template and the school's written specification as authoritative for all headers and footers. Preserve section-specific content, PAGE fields, first-page settings, odd/even settings, and linkage to previous sections.
- Preserve template-defined styles. Avoid manual spacing with blank lines or spaces.

## Pagination

- Keep pages before the Chinese abstract template-controlled. Do not add a visible page number where the template leaves one blank.
- Unless the template or written specification explicitly requires another scheme, start uppercase Roman page numbers (`I`, `II`, `III`) at the Chinese abstract and continue through the final page before Chapter 1.
- Restart page numbering with Arabic numeral `1` on the first page of Chapter 1.
- Continue the Arabic sequence through references, acknowledgements, and appendices unless the template explicitly resets it.
- Implement numbering with Word section breaks, `PAGE` fields, and section page-number properties. Never type page numbers manually.
- When a new section break is necessary, preserve or clone the applicable template header/footer configuration and linkage behavior.
- Refresh `TOC`, `PAGE`, `NUMPAGES`, header, and footer fields before final rendering. Confirm the rendered page count matches cached total-page fields.

## Structure

- Include the required Chinese abstract and keywords.
- Include the English abstract and keywords when required by the template.
- Keep headings consistent with the approved outline.
- Use real Word heading styles and update the existing TOC field.
- Keep references, appendices, and acknowledgements in the template-defined order.

## Formatting

- Confirm title fonts, font sizes, weight, alignment, indentation, line spacing, before/after spacing, and numbering.
- Confirm Chinese and English fonts separately.
- Keep figure captions, table captions, numbering, cross-references, and placement consistent.
- Inspect table borders, widths, cell alignment, wrapping, and page breaks.
- Follow an explicit template or school table-border specification when one exists. Otherwise, confirm that each table is a standard three-line table with no vertical borders, a `1.5 pt` top border, a `0.75 pt` separator below the final header row, a `1.5 pt` bottom border, and no other internal horizontal borders.
- Run `scripts/audit_three_line_tables.py` and treat deviations as blocking unless a template-specific exception is documented.
- Confirm the rendered TOC page numbers match final pagination. If a static TOC fallback is used, disclose it and recalculate the entries after layout is final.
- Inspect every rendered page for clipping, overlap, unexpected blank pages, isolated headings, missing glyphs, and shifted page furniture.

## Evidence

- Validate the reference inventory.
- Verify each final bibliography entry against its database record or supplied source.
- Confirm that every empirical chart and table has traceable data.
- Mark unsupported sections rather than inventing content.
- Run the thesis consistency audit after edits. Treat stale terms, duplicate captions, and references without captions as blocking errors.
- Statements such as test results, statistical agreement, and stable operation require traceable user-provided evidence or an explicit unverified label such as `待实际测试验证`. Treat unsupported evidence claims as blocking errors.
- Audit references for recent-source ratio, duplicate entries, DOI syntax, URL syntax,正文 citations without bibliography entries, and bibliography entries not cited in the body. Use optional HTTP verification when appropriate, but retain manual academic-database verification.

## Headers

- When a title changes, synchronize only main-body and later-section headers.
- Never globally replace all header parts. Protect cover, declaration, abstract, and TOC sections.
- Re-run the complete protected-front-matter hash check after header synchronization.

## Images

- Run `scripts/audit_thesis_images.py`.
- Confirm each image has an adjacent caption and each caption is referenced in the body where appropriate.
- Confirm figure numbering is continuous within each chapter.
- Review effective image resolution and replace unclear images.
- For chart-like figures, add a nearby traceable data source or mark the data as `待核验`.

## Rendering

- Render every final DOCX to page PNGs and inspect all pages at 100% zoom.
- On Windows, use `scripts/render_docx_windows.py` when the installed renderer cannot locate LibreOffice or Poppler. The script auto-detects common system and bundled executable locations and uses an isolated LibreOffice profile.

## Delivery

- Deliver the final `.docx`.
- Deliver the verified reference inventory.
- Deliver editable HTML/CSS/SVG sources for generated explanatory figures.
- Deliver source datasets for generated data charts.
- State any missing source, unresolved limitation, or skipped QA step.
