# Thesis intake checklist

Collect only the information needed for the next decision.

## Required before outline approval

- School `.docx` template, if available.
- Example thesis and school writing specification, if available.
- Thesis title, major, education level, and target length.
- Required chapter structure and deadline.
- Required Chinese abstract, English abstract, keywords, appendices, and acknowledgements.
- Existing draft, research proposal, assignment brief, notes, and supervisor feedback.
- Canonical thesis title, accepted short system name, and any old titles or stale terms that must be removed from editable content and headers.
- Whether main-body headers should be synchronized to the canonical title while protected front-matter headers remain unchanged.
- Available research materials: literature PDFs, datasets, questionnaires, interview notes, experiment records, screenshots, and source code.
- User-provided test-case sheets, execution logs, screenshots, database query records, or other evidence required to support claims such as `测试结果表明`, `运行稳定`, or `统计结果一致`.
- Traceable datasets or provenance notes for each chart-like figure. When unavailable, confirm that the affected chart must be labeled `待核验`.
- Explicitly protected pages or paragraphs beyond the cover, declarations, and authorization pages.

## Required before drafting evidence-dependent sections

- Confirmed outline.
- Research method.
- Data provenance and collection period.
- Whether the work is literature-based, system-design based, survey-based, case-based, or experimental.
- Constraints on reference count, publication years, languages, and source types.

## Clarify when needed

- Determine whether the Chinese abstract heading marks the first editable paragraph. The protection script automatically normalizes spacing variants such as `摘要` and `摘  要`, but the matched heading and rendered boundary must still be reviewed.
- Determine whether the English abstract mirrors the Chinese abstract.
- Determine the Chinese abstract location and the exact first main-body heading that must restart at Arabic page `1`.
- Determine whether the school uses numbered citations, author-year citations, footnotes, or another template-defined style.
- Determine whether the template already contains an automatic table of contents.
- Determine whether figures and tables need a chapter prefix such as `图 2-1` or `表 3-2`.
- Determine whether the school explicitly requires a Roman-numeral case from the Chinese abstract to the page before Chapter 1. Default to uppercase Roman numerals (`I`, `II`, `III`) when the template and specification are silent.
- Determine whether the school explicitly requires a table-border style. When the template and specification are silent, default to a standard three-line table with no vertical borders, `1.5 pt` top and bottom borders, and a `0.75 pt` separator below the final header row.
- Determine whether references, acknowledgements, and appendices continue the main-body Arabic sequence or require a separate reset.
- Determine whether headers and footers differ between cover pages, abstracts, TOC, main body, references, acknowledgements, or appendices.
- Determine whether first-page headers/footers or odd/even-page headers/footers are enabled in any section.
