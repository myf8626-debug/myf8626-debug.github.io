# Citation and evidence policy

## Source integrity

- Include a reference only after verifying title, authors, year, publication source, and a DOI, database identifier, or stable URL.
- Do not invent citations, DOI values, journal names, issue numbers, page ranges, quotations, or database records.
- Distinguish metadata verification from full-text verification. Metadata and abstracts do not support claims that require reading the full article.
- Request a legally obtained PDF or accessible full text when a detailed claim depends on the source body.
- Do not bypass login, subscription, CAPTCHA, rate limit, or download restrictions.

## Recency

- Prefer literature from the latest five calendar years relative to the current task date.
- Allow older standards, government policies, authoritative definitions, and foundational theory when necessary.
- Mark each older source as a classic or required source and state why it remains relevant.

## Evidence inventory

Maintain a UTF-8 CSV file with these columns:

```text
title,authors,year,source,identifier,url,verified_on,is_classic,classic_reason,supports
```

- Use `identifier` for DOI, CNKI record identifiers, VIP record identifiers, ISBN, standard numbers, or another stable database identifier.
- Use `verified_on` in `YYYY-MM-DD` format.
- Set `is_classic` to `true` only for justified older sources.
- Use `supports` to record the section or claim supported by the source.

Run:

```powershell
python scripts/validate_references.py references.csv --docx edited.docx --out-json reference-audit.json
```

This script checks inventory structure, recent-source ratio, duplicate entries, DOI and URL syntax, and optional DOCX numeric-citation consistency. Add `--check-links` when HTTP reachability checks are appropriate. It does not prove that a reference exists or supports a claim; manually verify each record against an academic database or the supplied full text.

## Writing discipline

- Cite claims close to the sentence or paragraph they support.
- Do not cite a source for a conclusion beyond the accessible evidence.
- Label inference as inference.
- Use the citation and bibliography format already present in the school template.
